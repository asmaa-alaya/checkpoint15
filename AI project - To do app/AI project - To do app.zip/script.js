// Get references to DOM elements
const taskInput = document.getElementById("taskInput");
const addButton = document.getElementById("addButton");
const taskList = document.getElementById("taskList");

// Load tasks from local storage if they exist
document.addEventListener("DOMContentLoaded", loadTasks);

// Add a task
addButton.addEventListener("click", () => {
  const taskText = taskInput.value.trim();
  
  if (taskText !== "") {
    addTaskToDOM(taskText);
    saveTaskToLocalStorage(taskText);
    taskInput.value = ""; // clear the input
  }
});

// Load tasks from local storage and display them
function loadTasks() {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  tasks.forEach(task => addTaskToDOM(task.text, task.completed));
}

// Add a task to the DOM
function addTaskToDOM(taskText, completed = false) {
  const li = document.createElement("li");
  li.classList.toggle("completed", completed);
  
  const taskSpan = document.createElement("span");
  taskSpan.textContent = taskText;
  taskSpan.addEventListener("click", () => toggleTaskCompletion(li, taskText));
  
  const deleteButton = document.createElement("button");
  deleteButton.textContent = "Delete";
  deleteButton.classList.add("delete");
  deleteButton.addEventListener("click", () => deleteTask(li, taskText));

  li.appendChild(taskSpan);
  li.appendChild(deleteButton);
  taskList.appendChild(li);
}

// Mark task as completed or not
function toggleTaskCompletion(li, taskText) {
  li.classList.toggle("completed");
  updateTaskInLocalStorage(taskText, li.classList.contains("completed"));
}

// Delete a task
function deleteTask(li, taskText) {
  li.remove();
  deleteTaskFromLocalStorage(taskText);
}

// Save task to local storage
function saveTaskToLocalStorage(taskText) {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  tasks.push({ text: taskText, completed: false });
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Update task status in local storage
function updateTaskInLocalStorage(taskText, completed) {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  const task = tasks.find(t => t.text === taskText);
  if (task) {
    task.completed = completed;
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }
}

// Delete task from local storage
function deleteTaskFromLocalStorage(taskText) {
  const tasks = JSON.parse(localStorage.getItem("tasks")) || [];
  const updatedTasks = tasks.filter(task => task.text !== taskText);
  localStorage.setItem("tasks", JSON.stringify(updatedTasks));
}
